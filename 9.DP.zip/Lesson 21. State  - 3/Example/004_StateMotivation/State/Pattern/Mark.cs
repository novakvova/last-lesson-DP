﻿namespace State
{
    public enum Mark
    {
        Two = 2,
        Five = 5
    }
}