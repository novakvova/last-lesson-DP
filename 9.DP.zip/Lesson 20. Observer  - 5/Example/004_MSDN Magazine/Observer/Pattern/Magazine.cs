﻿using System;

namespace Observer
{
    class Magazine
    {
        public string Title { get; set; }
        public string Content { get; set; }
    }
}
