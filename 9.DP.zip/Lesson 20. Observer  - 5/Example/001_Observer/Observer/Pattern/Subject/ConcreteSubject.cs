using System;

namespace Observer
{
    class ConcreteSubject : Subject
    {
        public string State { get; set; }
    }
}
