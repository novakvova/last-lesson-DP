using System;

namespace Observer
{
    abstract class Observer
    {
        public abstract void Update();
    }
}
