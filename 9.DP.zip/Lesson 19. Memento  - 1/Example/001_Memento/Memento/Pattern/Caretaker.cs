using System;

namespace Memento
{
    class Caretaker
    {
        public Memento Memento { get; set; }
    }
}
