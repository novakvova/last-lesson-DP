using System;

namespace Memento
{
    class Robot
    {
        public Backpack Backpack
        {
            get;
            set;
        }
    }
}
