using System;

namespace Memento
{
    class Backpack
    {
        public string �ontents
        {
            get;
            private set;
        }

        public Backpack(string �ontents)
        {
            this.�ontents = �ontents;
        }
    }
}
