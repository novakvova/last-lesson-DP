using System;

namespace Memento
{
    class Caretaker
    {
        public INarrowInterface Memento { get; set; }
    }
}
