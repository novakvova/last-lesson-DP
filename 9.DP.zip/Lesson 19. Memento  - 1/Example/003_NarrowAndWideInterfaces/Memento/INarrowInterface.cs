﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Memento
{
    // Узкий интерфейс
    interface INarrowInterface
    {
    }
}
