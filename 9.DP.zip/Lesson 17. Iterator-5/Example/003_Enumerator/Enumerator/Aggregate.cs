﻿
namespace Enumerator
{
    interface IEnumerable
    {
        IEnumerator GetEnumerator();
    }
}