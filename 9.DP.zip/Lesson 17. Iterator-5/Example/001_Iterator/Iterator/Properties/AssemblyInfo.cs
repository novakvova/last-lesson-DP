﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("GoF")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("edu.cbsystematics.com")]
[assembly: AssemblyProduct("GoF")]
[assembly: AssemblyCopyright("Copyright © CyberBionic Systematics 2012")]
[assembly: AssemblyTrademark("CyberBionic Systematics")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("9357c46a-4705-42c2-a3d9-69cea54e3d68")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
