﻿using System;

namespace Enumerator
{
    class Banknote
    {
        public string Nominal = "100 $";
    }
}
