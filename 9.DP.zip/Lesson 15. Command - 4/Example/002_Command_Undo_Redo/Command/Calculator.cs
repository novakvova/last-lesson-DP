﻿using System;

namespace Command
{
    // "Client"
    class Calculator
    {
        ArithmeticUnit arithmeticUnit; // "Receiver" (Получатель) - Арифметическое устройство (АУ)
        ControlUnit controlUnit; // "Invoker" (Инициатор) - Устройство управления (УУ)

        public Calculator()
        {
            arithmeticUnit = new ArithmeticUnit();
            controlUnit = new ControlUnit();
        }

        private int Run(Command command)
        {
            controlUnit.StoreCommand(command);
            controlUnit.ExecuteCommand();
            return arithmeticUnit.Register;  //як він знає який Буде рузультат, він його знає, бо
        }                                   //у конуструктор команди ми передали поточний обєкт
        //arithmeticUnit, якщо ми його туди передали, він виконав операції і може видати результат

        public int Add(int operand)
        {
            return Run(new Add(arithmeticUnit, operand));
        }

        public int Sub(int operand)
        {
            return Run(new Sub(arithmeticUnit, operand));
        }

        public int Mul(int operand)
        {
            return Run(new Mul(arithmeticUnit, operand));
        }

        public int Div(int operand)
        {
            return Run(new Div(arithmeticUnit, operand));
        }

        public int Undo(int levels)
        {
            controlUnit.Undo(levels);
            return arithmeticUnit.Register;
        }

        public int Redo(int levels)
        {
            controlUnit.Redo(levels);
            return arithmeticUnit.Register;
        }
    }
}
