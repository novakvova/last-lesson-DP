using System;

namespace Strategy
{
    abstract class Strategy
    {
        public abstract void AlgorithmInterface();
    }
}
