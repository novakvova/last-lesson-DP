using System;

namespace Strategy
{
    abstract class Strategy
    {
        public abstract void Sort(ref int[] array);
    }
}
